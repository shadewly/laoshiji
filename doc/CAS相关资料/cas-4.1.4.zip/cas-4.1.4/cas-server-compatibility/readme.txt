These are the automated compatibility tests.

Andrew's environment:
They run for me in Eclipse under 
JDK 1.5 with xercesImpl.jar 
(from uPortal) also on the classpath.